#ifndef __SEQUENCIAL__
#define __SEQUENCIAL__

/*
    Calcula a quantidade de itens por pagina
*/
int calculaItensPorPagina(int);

#endif

