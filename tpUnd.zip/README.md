# tp-ed2-pt1
Primeiro trabalho prática de Estrutura de Dados 2
